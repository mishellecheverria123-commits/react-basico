import React from 'react';

function Tarea({ texto, completada, eliminarTarea, toggleCompletada }) {
  return (
    <li>
      {/* <span> con estilo condicional: tachado si está completada */}
      <span style={{ textDecoration: completada ? 'line-through' : 'none', marginRight: '10px' }}>
        {texto}
      </span>
      {/* Botones que llaman a las funciones (callbacks) pasadas por props */}
      <button onClick={toggleCompletada} style={{ marginRight: '5px' }}> ✔ </button>
      <button onClick={eliminarTarea}> ❌ </button>
    </li>
  );
}

export default Tarea;