import React, { useState } from 'react';
import Tarea from './Tarea'; 
function GestorTareas() {
  const [tareas, setTareas] = useState([]);
  const [nuevaTareaTexto, setNuevaTareaTexto] = useState('');

  const agregarTarea = () => {
    if (nuevaTareaTexto.trim() !== '') {
      const nuevaTarea = {
        id: Date.now(), 
        texto: nuevaTareaTexto,
        completada: false,
      };
      setTareas([...tareas, nuevaTarea]); 
      setNuevaTareaTexto('');
    }
  };

  const eliminarTarea = (id) => {
    setTareas(tareas.filter(tarea => tarea.id !== id));
  };

  const toggleCompletada = (id) => {
    setTareas(
      tareas.map(tarea =>
        tarea.id === id ? { ...tarea, completada: !tarea.completada } : tarea
      )
    );
  };

  return (
    <div style={{ padding: '20px', maxWidth: '400px', margin: '0 auto' }}>
      <h1>Gestor de Tareas</h1>
      {/* Formulario para agregar tareas */}
      <div>
        <input
          type="text"
          placeholder="Escribe una tarea"
          value={nuevaTareaTexto}
          onChange={(e) => setNuevaTareaTexto(e.target.value)}
          style={{ padding: '10px', marginRight: '10px' }}
        />
        <button onClick={agregarTarea} style={{ padding: '10px' }}>Agregar Tarea</button>
      </div>

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {/* Renderizado Condicional: Mostrar mensaje si no hay tareas  */}
        {tareas.length === 0 ? (
          <p style={{ fontStyle: 'italic', marginTop: '20px' }}>“No tienes tareas pendientes”</p>
        ) : (
          /* Renderizado Dinámico de la lista [cite: 72] */
          tareas.map((tarea) => (
            <Tarea
              key={tarea.id} // Clave única esencial
              texto={tarea.texto}
              completada={tarea.completada}
              eliminarTarea={() => eliminarTarea(tarea.id)}
              toggleCompletada={() => toggleCompletada(tarea.id)}
            />
          ))
        )}
      </ul>
    </div>
  );
}

export default GestorTareas;