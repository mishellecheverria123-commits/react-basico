import React from 'react';
import './App.css'; 
import GestorTareas from './GestorTareas';

function App() {
  return (
    <GestorTareas />
  );
}

export default App;