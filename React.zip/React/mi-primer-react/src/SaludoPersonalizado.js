
import { useState } from 'react'; 

function SaludoPersonalizado() {
  const [nombre, setNombre] = useState(''); 

  const borrarTexto = () => { 
      setNombre('');
  };

  return (
    <div>
      <p>Saludo Personalizado</p>
      
      <input
        type="text"
        placeholder="Escribe tu nombre"
        onChange={(e) => setNombre(e.target.value)} 
        value={nombre} 
      />
      
      <button onClick={borrarTexto}>Borrar</button>

      <h2>Hola {nombre || 'visitante'} 👋 </h2>
    </div>
  );
}

export default SaludoPersonalizado;