import { useState } from 'react'; 

function Contador() {
  const [contador, setContador] = useState(0); 

  return (
    <div>
      <h3>Contador: {contador}</h3>
      {/* Botón para incrementar: Llama a setContador con el valor + 1 [cite: 61] */}
      <button onClick={() => setContador(contador + 1)}>+</button> 
      {/* Botón para decrementar: Llama a setContador con el valor - 1 [cite: 62] */}
      <button onClick={() => setContador(contador - 1)}>-</button> 
    </div>
  );
}

export default Contador; 