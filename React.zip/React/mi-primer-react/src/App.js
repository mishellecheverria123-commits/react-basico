import React from 'react';
import './App.css'; 
import Saludo from './Saludo';
import Contador from './Contador';
import SaludoPersonalizado from './SaludoPersonalizado'; 

function App() {
  return (
    <div className="App">
      <h1>Hoja de Trabajo - Resultados</h1>

      <hr />

      {/* 1. Saludos con Props */}
      <h2>1. Saludos con Props</h2>
      <Saludo nombre="Ana" />
      <Saludo nombre="Luis" />
      <Saludo nombre="María" />
      
      <hr />
      
      {/* 2. Contador con Estado */}
      <h2>2. Contador con Estado</h2>
      <Contador />
      
      <hr />
      
      {/* 3. Reto Saludo Personalizado */}
      <h2>3. Reto Saludo Personalizado</h2>
      <SaludoPersonalizado />
    </div>
  );
}

export default App;