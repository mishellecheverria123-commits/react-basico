function Saludo({ nombre }) {
    return <h2>Hola {nombre}, ¡bienvenido a React!</h2>;
  }
  

  export default Saludo;